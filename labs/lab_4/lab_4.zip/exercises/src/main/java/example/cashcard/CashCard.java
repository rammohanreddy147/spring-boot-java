package example.cashcard;

public record CashCard(Long id, Double amount) {
}
